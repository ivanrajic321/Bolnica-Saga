/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personalizacija;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author irajic
 */
@Entity
@Table(name = "SPISAK_LEKARA", catalog = "", schema = "IVAN")
@NamedQueries({
    @NamedQuery(name = "SpisakLekara.findAll", query = "SELECT s FROM SpisakLekara s")
    , @NamedQuery(name = "SpisakLekara.findByIme", query = "SELECT s FROM SpisakLekara s WHERE s.ime = :ime")
    , @NamedQuery(name = "SpisakLekara.findByPrezime", query = "SELECT s FROM SpisakLekara s WHERE s.prezime = :prezime")
    , @NamedQuery(name = "SpisakLekara.findById", query = "SELECT s FROM SpisakLekara s WHERE s.id = :id")
    , @NamedQuery(name = "SpisakLekara.findByJmbg", query = "SELECT s FROM SpisakLekara s WHERE s.jmbg = :jmbg")
    , @NamedQuery(name = "SpisakLekara.findByBrojOrdinacije", query = "SELECT s FROM SpisakLekara s WHERE s.brojOrdinacije = :brojOrdinacije")})
public class SpisakLekara implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Column(name = "IME")
    private String ime;
    @Column(name = "PREZIME")
    private String prezime;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    private BigDecimal id;
    @Column(name = "JMBG")
    private BigInteger jmbg;
    @Column(name = "BROJ_ORDINACIJE")
    private BigInteger brojOrdinacije;

    public SpisakLekara() {
    }

    public SpisakLekara(BigDecimal id) {
        this.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        String oldIme = this.ime;
        this.ime = ime;
        changeSupport.firePropertyChange("ime", oldIme, ime);
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        String oldPrezime = this.prezime;
        this.prezime = prezime;
        changeSupport.firePropertyChange("prezime", oldPrezime, prezime);
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        BigDecimal oldId = this.id;
        this.id = id;
        changeSupport.firePropertyChange("id", oldId, id);
    }

    public BigInteger getJmbg() {
        return jmbg;
    }

    public void setJmbg(BigInteger jmbg) {
        BigInteger oldJmbg = this.jmbg;
        this.jmbg = jmbg;
        changeSupport.firePropertyChange("jmbg", oldJmbg, jmbg);
    }

    public BigInteger getBrojOrdinacije() {
        return brojOrdinacije;
    }

    public void setBrojOrdinacije(BigInteger brojOrdinacije) {
        BigInteger oldBrojOrdinacije = this.brojOrdinacije;
        this.brojOrdinacije = brojOrdinacije;
        changeSupport.firePropertyChange("brojOrdinacije", oldBrojOrdinacije, brojOrdinacije);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SpisakLekara)) {
            return false;
        }
        SpisakLekara other = (SpisakLekara) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Personalizacija.SpisakLekara[ id=" + id + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
